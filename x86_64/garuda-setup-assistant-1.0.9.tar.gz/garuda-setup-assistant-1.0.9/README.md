# garuda-setup-assistant

A setup assistant for Garuda Linux